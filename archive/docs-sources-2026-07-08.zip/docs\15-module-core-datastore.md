# 15 — Модуль `:core:datastore`

**Роль:** пользовательские настройки через Preferences DataStore. Маленький модуль — и это нормально.

**Зависимости:** `:core:model` (типы `UserSettings`, enum-ы), `:core:common`, `androidx.datastore:datastore-preferences`.

## Содержимое

```kotlin
class SettingsDataSource @Inject constructor(private val dataStore: DataStore<Preferences>) {

    private object Keys {
        val TEMP_UNIT = stringPreferencesKey("temperature_unit")
        val WIND_UNIT = stringPreferencesKey("wind_speed_unit")
        val THEME = stringPreferencesKey("theme_mode")
    }

    val settings: Flow<UserSettings> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }  // ⚠️ повреждённый файл ≠ крэш
        .map { prefs ->
            UserSettings(
                temperatureUnit = prefs[Keys.TEMP_UNIT].toEnumOrDefault(TemperatureUnit.CELSIUS),
                windSpeedUnit = prefs[Keys.WIND_UNIT].toEnumOrDefault(WindSpeedUnit.METERS_PER_SECOND),
                theme = prefs[Keys.THEME].toEnumOrDefault(ThemeMode.SYSTEM),
            )
        }

    suspend fun setTemperatureUnit(unit: TemperatureUnit) { dataStore.edit { it[Keys.TEMP_UNIT] = unit.name } }
    // ... аналогично для остальных
}
```

Hilt-модуль: `PreferenceDataStoreFactory.create(...)`, файл `settings.preferences_pb`, **@Singleton обязательно** — два инстанса DataStore на один файл = `IllegalStateException` в рантайме.

## Тонкости

- Enum храним строкой `name` + безопасный парс с дефолтом (`toEnumOrDefault`) — переживает переименования и битые значения.
- Дефолты (°C, м/с, системная тема) живут в одном месте — здесь.
- Выбранный город здесь **не** храним — он в Room (`isSelected`), потому что это данные, а не настройка, и он участвует в join-логике погоды.
- Preferences, а не Proto DataStore: для 3 ключей прото-схема — овер. Сказать это на собеседовании — плюс.

## Тесты
- Round-trip: set → Flow эмитит новое значение (реальный DataStore во временной папке, `runTest`)
- Битое значение в prefs → дефолт, не крэш

## Критерии готовности
- [ ] Настройки переживают перезапуск приложения
- [ ] Смена значения мгновенно (реактивно) видна на всех экранах
