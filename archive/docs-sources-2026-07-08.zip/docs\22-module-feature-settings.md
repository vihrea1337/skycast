# 22 — Модуль `:feature:settings`

**Роль:** настройки + «О приложении». Самая простая фича — делаем её образцово-показательной.

Зависит от `:core:domain`, `:core:designsystem`, `:core:model`.

## Экран

**Секция «Единицы»**
- Температура: °C / °F (SegmentedButton)
- Скорость ветра: м/с / км/ч

**Секция «Внешний вид»**
- Тема: Системная / Светлая / Тёмная (radio-группа или диалог)

**Секция «О приложении»**
- Версия (из `BuildConfig.VERSION_NAME`, прокинуть через `:app` или gradle-поле)
- «Данные о погоде: Open-Meteo.com (CC-BY 4.0)» — ссылка; **атрибуция обязательна по лицензии**
- Ссылка на GitHub-репозиторий проекта
- Лицензии open-source (достаточно простого текстового экрана или AboutLibraries — опционально)

## ViewModel

```kotlin
val uiState: StateFlow<SettingsUiState> = observeSettingsUseCase()
    .map { SettingsUiState.Loaded(it) }
    .stateIn(viewModelScope, WhileSubscribed(5_000), SettingsUiState.Loading)

fun onTemperatureUnitChange(unit: TemperatureUnit) = viewModelScope.launch { updateSettingsUseCase.setTemperatureUnit(unit) }
```

Никакого локального стейта-копии: нажали → записали в DataStore → Flow сам вернул новое значение → UI обновился. Тот же UDF-круг, что и с погодой.

## Тонкости — эффект смены единиц

Единицы конвертирует **сервер** (см. `13-module-core-network.md`), поэтому смена °C→°F требует refresh. Решение: `SetTemperatureUnitUseCase` после записи в DataStore дёргает `RefreshWeatherUseCase`. Пока сети нет — Home продолжает показывать старые единицы; в `Content`-стейте подписи единиц брать из тех же настроек, с которыми грузились данные (хранить единицы в момент синка в БД рядом с погодой — поле `tempUnitAtSync`), иначе будет «21» с подписью «°F». Это тонкий момент — описать решение в README.

Смена темы — мгновенная: MainActivity подписана на `ObserveSettingsUseCase` и передаёт `themeMode` в `SkyCastTheme`.

## Тесты
- ViewModel: смена значения вызывает use case; state отражает DataStore
- Use case смены единиц: записал → дёрнул refresh (порядок verify в MockK)

## Критерии готовности
- [ ] Все настройки переживают перезапуск и мгновенно отражаются на Home
- [ ] Атрибуция Open-Meteo присутствует и кликабельна
