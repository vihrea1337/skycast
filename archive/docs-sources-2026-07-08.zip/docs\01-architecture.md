# 01 — Архитектура

## Принципы

1. **Clean Architecture light** — три слоя: data → domain → presentation. «Light», потому что без фанатизма: domain-слой тонкий, без отдельных domain-интерфейсов на каждый чих.
2. **UDF (Unidirectional Data Flow)** — состояние течёт вниз (`StateFlow<UiState>` из ViewModel в Compose), события вверх (лямбды `onEvent`).
3. **Offline-first** — Room = единственный источник правды (Single Source of Truth). UI **никогда** не читает из сети напрямую; сеть только пополняет БД.
4. **Многомодульность** — по типу (`core`) и по фиче (`feature`). Демонстрирует владение Gradle и ускоряет сборку.

## Граф модулей

```mermaid
graph TD
    app --> feature-home & feature-search & feature-settings & widget
    feature-home & feature-search & feature-settings --> core-domain & core-designsystem
    widget --> core-domain
    core-domain --> core-data
    core-data --> core-network & core-database & core-datastore
    core-network & core-database & core-datastore & core-data & core-domain --> core-model
    core-data & core-network --> core-common
```

## Правила зависимостей (нарушать нельзя)

| Правило | Зачем |
|---|---|
| `feature` не зависит от `feature` | Навигация между фичами — через `:app` (NavHost) |
| `feature` не видит `core:network` / `core:database` | UI не знает, откуда данные; только repository/use case |
| `core:model` и `core:common` — чистый Kotlin (`kotlin("jvm")`), без Android | Быстрые unit-тесты, честный domain |
| Никаких циклов | Gradle всё равно не даст, но проектировать надо заранее |

## Поток данных (пример: экран Home)

```
Compose UI ──collectAsStateWithLifecycle──> HomeViewModel.uiState: StateFlow<HomeUiState>
     │ onRefresh()                              ▲
     ▼                                          │ combine(weather, settings) → UiState
HomeViewModel ──> ObserveWeatherUseCase ──> WeatherRepository
                                                │ observe: Flow из Room DAO   ← SSOT
                                                │ refresh: Retrofit → мапперы → Room.upsert
                                                ▼
                                     (Room обновился → Flow сам эмитит → UI сам перерисовался)
```

Ключевой момент для собеседования: **`refresh()` ничего не возвращает в UI напрямую** (кроме ошибки) — данные приходят реактивно через Flow из БД.

## Состояния экрана

```kotlin
sealed interface HomeUiState {
    data object Loading : HomeUiState
    data class Success(val weather: WeatherData, val isRefreshing: Boolean) : HomeUiState
    data class Error(val error: AppError, val cached: WeatherData?) : HomeUiState // ошибка ≠ пустой экран
}
```

В ViewModel: `combine(...).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), Loading)` — стандартный паттерн, знать почему `5_000` (переживает поворот экрана, но освобождает ресурсы в фоне).

## Обработка ошибок

- Единый `AppResult<T>` / `AppError` в `:core:common` (см. `11-module-core-common.md`). Исключения ловятся на границе data-слоя (`safeApiCall`), выше летят только типизированные ошибки.
- UI-правило: если в кэше есть данные — показываем их + snackbar об ошибке; пустой error-экран только когда показывать нечего.

## Соглашения

- Пакеты: `com.<ник>.skycast.<модуль>...`; имена файлов = имя главного класса.
- Compose: экран = `XxxScreen(state, onEvent)` (stateless, легко превьюить) + `XxxRoute(viewModel)` (обвязка). Preview на каждый экран/состояние.
- Один Activity (`MainActivity`), диалоги и bottom sheets — тоже Compose.
- Строки только через `strings.xml` (сразу `values/` en + `values-ru/`), никаких хардкодов.
