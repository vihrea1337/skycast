# 17 — Модуль `:core:domain`

**Роль:** use cases — тонкая прослойка между репозиториями и ViewModel. Чистый Kotlin + coroutines, зависит только от `:core:data` (интерфейсы репозиториев), `:core:model`, `:core:common`.

## Честный разговор про этот слой

Для приложения такого размера use cases почти всегда просто делегируют репозиторию. Слой оставляем по двум причинам (проговорить в README и на собеседовании):
1. Демонстрация понимания Clean Architecture и точки расширения — когда логика появляется (см. `GetWeatherForSelectedCityUseCase` ниже), ей есть место, и ViewModel не жиреет.
2. ViewModel зависят от узких одноцелевых классов, а не от «толстого» репозитория — проще мокать и читать.

Анти-паттерн, который НЕ делаем: use case на каждый чих с пустым делегированием + интерфейс + Impl. Use case = финальный класс с `operator fun invoke`, без интерфейсов.

## Список use cases

```kotlin
// Единственный с реальной логикой — комбинирует погоду и настройки для UI:
class ObserveWeatherUseCase @Inject constructor(
    private val weatherRepo: WeatherRepository,
    private val settingsRepo: SettingsRepository,
) {
    operator fun invoke(): Flow<WeatherWithSettings?> =
        combine(weatherRepo.observeWeather(), settingsRepo.settings) { w, s ->
            w?.let { WeatherWithSettings(it, s) }
        }
}

class RefreshWeatherUseCase(...)        { suspend operator fun invoke(): AppResult<Unit> }      // + правило «не чаще раза в минуту» (debounce спам-обновлений)
class SearchCityUseCase(...)            { suspend operator fun invoke(query: String): AppResult<List<Location>> } // + trim, минимум 2 символа
class ObserveSavedLocationsUseCase(...) 
class SelectLocationUseCase(...)        // select + сразу RefreshWeather для нового города
class SaveLocationUseCase(...)          // save + select + refresh
class DeleteLocationUseCase(...)        // + правило: нельзя удалить последний/выбранный без переназначения selected
class DetectMyLocationUseCase(...)      // detectCurrent + save + refresh — целый сценарий, оправдывает слой
class ObserveSettingsUseCase(...); class UpdateSettingsUseCase(...)
```

Обрати внимание: `SelectLocation`, `SaveLocation`, `DetectMyLocation` — **композитные сценарии** из нескольких вызовов репозиториев. Именно они оправдывают существование слоя.

## Тесты
Каждый композитный use case — unit-тест с MockK: порядок вызовов, обработка ошибки на середине сценария (например, save прошёл, refresh упал — город должен остаться сохранённым, ошибка уйти наверх).

## Критерии готовности
- [ ] ViewModel не инжектят репозитории напрямую — только use cases
- [ ] Модуль без Android-зависимостей
