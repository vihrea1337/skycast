# 14 — Модуль `:core:database`

**Роль:** локальный кэш (Room) — единственный источник правды для UI. Наружу — DAO и entities; сам `RoomDatabase` наружу не торчит.

**Зависимости:** `:core:model` (для enum-ов через конвертеры — допустимо), Room (runtime/ktx через implementation, compiler через ksp).

## Схема

```
LocationEntity(id PK, name, region, country, latitude, longitude,
               isSelected: Boolean, sortOrder: Int)          // сохранённые города; ровно один isSelected
CurrentWeatherEntity(locationId PK → FK Location(CASCADE), temperature, feelsLike,
               humidity, pressure, windSpeed, wmoCode, isDay, updatedAtEpochSec)
HourlyForecastEntity(id PK autogen, locationId FK(CASCADE) + index, time, temperature, wmoCode, precipProb)
DailyForecastEntity(id PK autogen, locationId FK(CASCADE) + index, date, tempMin, tempMax, wmoCode, sunrise, sunset)
```

Хранение времени: epoch seconds (`Long`) — без TypeConverter-магии; даты часов/дней — ISO-строки от API как есть (парсит маппер в `:core:data`).

## DAO — ключевые запросы

```kotlin
@Dao interface WeatherDao {
    @Query("SELECT * FROM current_weather WHERE locationId = :locationId")
    fun observeCurrent(locationId: Long): Flow<CurrentWeatherEntity?>   // nullable! кэша может не быть

    @Transaction  // прогноз заменяем атомарно: delete + insert одним махом
    suspend fun replaceForecast(locationId: Long, current: CurrentWeatherEntity,
                                hourly: List<HourlyForecastEntity>, daily: List<DailyForecastEntity>)
}

@Dao interface LocationDao {
    @Query("SELECT * FROM locations ORDER BY sortOrder") fun observeAll(): Flow<List<LocationEntity>>
    @Query("SELECT * FROM locations WHERE isSelected = 1") fun observeSelected(): Flow<LocationEntity?>
    @Transaction suspend fun select(id: Long)  // снять старый isSelected, поставить новый — атомарно
}
```

## Тонкости

- DAO-методы, возвращающие `Flow`, — **не** suspend; suspend — только одноразовые операции.
- Flow из Room эмитит при **любом** изменении таблицы — для UI это фича (реактивность бесплатно).
- Миграции: пока схема пляшет (этапы 3–5) — `fallbackToDestructiveMigration()` + `exportSchema = false`. Перед `v1.0` включить `exportSchema = true`, папку `schemas/` в git — и с этого момента писать настоящие миграции. Отметить это в README — понимание миграций хорошо смотрится на собеседовании.
- FK + `ON DELETE CASCADE`: удаление города автоматически чистит его прогнозы — проверить тестом.

## Тесты (androidTest или Robolectric, in-memory database)

- replaceForecast: старые часы удалены, новые вставлены, атомарно
- select(): исключительность isSelected
- CASCADE при удалении города

## Критерии готовности
- [ ] UI-слой нигде не импортирует entities (только `:core:data` их видит)
- [ ] Тесты DAO зелёные
