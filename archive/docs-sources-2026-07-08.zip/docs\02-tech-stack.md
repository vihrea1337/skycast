# 02 — Технологический стек

Версии не фиксируются в доках — берём актуальные стабильные на момент подключения. Требования к окружению: **JDK 17+**, актуальные Android Studio / AGP, Kotlin 2.x (Compose-компилятор теперь плагин Kotlin — `org.jetbrains.kotlin.plugin.compose`).

## SDK

| Параметр | Значение | Почему |
|---|---|---|
| minSdk | 26 (Android 8.0) | ~97% устройств; `java.time` без desugaring |
| targetSdk / compileSdk | последний стабильный | Требование Google Play и хороший тон |

## Библиотеки по категориям

| Категория | Выбор | Почему именно это (ответ для собеседования) |
|---|---|---|
| UI | Jetpack Compose + Material 3 | Индустриальный стандарт; декларативный UI |
| Навигация | Navigation Compose, type-safe (`@Serializable` routes) | Официальное решение; типобезопасные маршруты вместо строк |
| DI | Hilt | Стандарт для Android; compile-time проверка графа vs Koin (runtime) |
| Асинхронность | Coroutines + Flow | Родное для Kotlin; RxJava — легаси |
| Сеть | Retrofit + OkHttp | Стандарт; декларативные интерфейсы, интерцепторы |
| JSON | kotlinx.serialization | Родная для Kotlin, compile-time, без рефлексии (vs Gson/Moshi) |
| БД | Room | SQLite с compile-time проверкой SQL, отдаёт Flow |
| Настройки | Preferences DataStore | Замена SharedPreferences: асинхронный, Flow, без ANR |
| Виджет | Glance | Compose-синтаксис для RemoteViews |
| Фоновые задачи | WorkManager | Гарантированное выполнение, учёт Doze |
| Геолокация | play-services-location (Fused) | Экономнее и точнее, чем голый LocationManager |
| Изображения | — (иконки погоды — свои векторы) | Coil подключить, только если появятся сетевые картинки |
| Splash | AndroidX Core SplashScreen | Единое поведение на всех версиях ОС |
| Тесты | JUnit4, MockK, Turbine, coroutines-test, MockWebServer, Compose UI Test | См. `30-testing.md` |
| Статанализ | detekt + ktlint (через плагин detekt-formatting) | См. `31-ci-cd.md` |
| Кодоген API | openapi-generator (Gradle plugin) | См. `03-api-swagger.md` |

## Version catalog — скелет `gradle/libs.versions.toml`

```toml
[versions]
# agp, kotlin, ksp, compose-bom, hilt, retrofit, room, ... — актуальные стабильные

[libraries]
# группируй по категориям, имена в kebab-case: retrofit-core, retrofit-kotlinx-serialization,
# okhttp-logging, room-runtime, room-ktx, room-compiler, hilt-android, hilt-compiler, ...

[bundles]
# удобно: bundles.room = ["room-runtime", "room-ktx"], bundles.retrofit = [...]

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
android-library = { id = "com.android.library", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
kotlin-serialization = { id = "org.jetbrains.kotlin.plugin.serialization", version.ref = "kotlin" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
hilt = { id = "com.google.dagger.hilt.android", version.ref = "hilt" }
```

## Подводные камни

- **KSP, не kapt** — для Room и Hilt (kapt медленный и в режиме поддержки).
- Compose BOM управляет версиями всех compose-артефактов — версии у отдельных compose-библиотек не указывать.
- `kotlinx-serialization` + Retrofit требует конвертер `retrofit2-kotlinx-serialization-converter` и `MediaType "application/json"`.
- В каждом библиотечном модуле не забывать `namespace` и одинаковые compileOptions/jvmTarget — иначе зоопарк; на этапе 1 можно вынести в convention plugin (`build-logic/`), но допустимо и копировать, для junior-mid проекта это не критично.
