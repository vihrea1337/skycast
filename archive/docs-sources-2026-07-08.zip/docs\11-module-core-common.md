# 11 — Модуль `:core:common`

**Роль:** фундаментальные типы и утилиты, нужные всем. Чистый Kotlin (`kotlin("jvm")`) — без Android SDK.

**Зависимости:** только kotlinx-coroutines-core. От этого модуля зависят почти все — поэтому он должен быть маленьким и стабильным (каждое изменение перекомпилирует полдерева).

## Содержимое

### Результат и ошибки

```kotlin
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Failure(val error: AppError) : AppResult<Nothing>
}

sealed interface AppError {
    data object Network : AppError                 // IOException — нет сети/таймаут
    data class Server(val code: Int) : AppError    // HTTP 4xx/5xx
    data object Unknown : AppError                 // всё остальное (включая ошибки парсинга)
}
```

Почему не встроенный `kotlin.Result`: он не типизирует ошибку (Throwable), а UI должен различать «нет сети» и «сервер упал» без instanceof-каскадов по исключениям.

### Диспетчеры через DI (обязательно для тестируемости)

```kotlin
@Qualifier annotation class Dispatcher(val type: DispatcherType)
enum class DispatcherType { IO, Default }
```

Hilt-модуль с провайдерами живёт здесь же. Правило: **никогда** не писать `Dispatchers.IO` напрямую в репозиториях — только инжект (в тестах подменяется на `StandardTestDispatcher`).

### Утилиты
Только то, что реально понадобилось дважды. Свалку `Utils.kt` не заводить.

## Критерии готовности
- [ ] Модуль без Android-зависимостей, собирается как JVM
- [ ] Ни одного `Dispatchers.IO` в коде проекта вне этого модуля (проверяется detekt-правилом Forbidden…/grep)
