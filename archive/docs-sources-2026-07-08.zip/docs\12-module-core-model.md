# 12 — Модуль `:core:model`

**Роль:** доменные модели — общий язык всех слоёв. Чистый Kotlin, без зависимостей вообще (кроме stdlib; `java.time` доступен при minSdk 26).

Это **не** DTO и **не** Room-entities: у сети и БД свои классы в своих модулях, сюда они **маппятся**. Тройное дублирование классов — осознанное: контракт API, схема БД и доменная модель меняются по разным причинам (ответ на собеседовании — Single Responsibility).

## Модели

```kotlin
data class Location(
    val id: Long,            // geonames id из geocoding API
    val name: String,
    val region: String?,     // admin1: «ХМАО»
    val country: String,
    val latitude: Double,
    val longitude: Double,
)

data class WeatherData(          // агрегат: всё, что нужно Home-экрану и виджету
    val location: Location,
    val current: CurrentWeather,
    val hourly: List<HourlyForecast>,   // ближайшие 24 ч
    val daily: List<DailyForecast>,     // 7 дней
    val updatedAt: Instant,             // для «обновлено N мин назад» и политики устаревания
)

data class CurrentWeather(
    val temperature: Double, val feelsLike: Double,
    val humidityPercent: Int, val pressureHpa: Double, val windSpeed: Double,
    val weatherType: WeatherType, val isDay: Boolean,
)

data class HourlyForecast(val time: LocalDateTime, val temperature: Double,
                          val weatherType: WeatherType, val precipitationProbability: Int)

data class DailyForecast(val date: LocalDate, val tempMin: Double, val tempMax: Double,
                         val weatherType: WeatherType, val sunrise: LocalDateTime, val sunset: LocalDateTime)

enum class WeatherType { CLEAR, PARTLY_CLOUDY, OVERCAST, FOG, DRIZZLE, RAIN, SNOW,
                         RAIN_SHOWERS, SNOW_SHOWERS, THUNDERSTORM;
    companion object { fun fromWmoCode(code: Int): WeatherType = ... } // единственная логика в модуле
}

// Настройки (живут в DataStore, но типы — здесь, т.к. нужны и domain, и UI)
enum class TemperatureUnit { CELSIUS, FAHRENHEIT }
enum class WindSpeedUnit { METERS_PER_SECOND, KILOMETERS_PER_HOUR }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
data class UserSettings(val temperatureUnit: TemperatureUnit, val windSpeedUnit: WindSpeedUnit, val theme: ThemeMode)
```

## Тонкости

- Температуры храним `Double`, округляем только при форматировании в UI.
- Время: `LocalDateTime` (API отдаёт локальное время точки при `timezone=auto`), `updatedAt` — `Instant` (момент синка). Не путать — типичный источник багов.
- Никаких методов форматирования («`getTemperatureString()`») в моделях — форматирование живёт в UI-слое.

## Критерии готовности
- [ ] `fromWmoCode` покрыт unit-тестом на все группы кодов
- [ ] В модуле нет ни одного import android.* / retrofit / room
