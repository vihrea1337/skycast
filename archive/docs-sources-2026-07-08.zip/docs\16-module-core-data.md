# 16 — Модуль `:core:data`

**Роль:** сердце data-слоя. Репозитории объединяют сеть + БД + датастор в offline-first API для domain/UI. Здесь же все мапперы DTO → Entity → доменная модель.

**Зависимости:** `:core:network`, `:core:database`, `:core:datastore`, `:core:model`, `:core:common`; play-services-location.

## Репозитории (интерфейс + Impl, @Binds в Hilt)

```kotlin
interface WeatherRepository {
    /** SSOT: только из Room. null — кэша ещё нет */
    fun observeWeather(): Flow<WeatherData?>            // погода выбранного города (flatMapLatest по selected location)
    /** Сеть → Room. UI получит данные реактивно через observe; наружу — только ошибка/успех */
    suspend fun refresh(): AppResult<Unit>
}

interface LocationRepository {
    fun observeSavedLocations(): Flow<List<Location>>
    fun observeSelected(): Flow<Location?>
    suspend fun search(query: String): AppResult<List<Location>>     // geocoding, БЕЗ сохранения
    suspend fun save(location: Location)                             // + сразу select
    suspend fun select(id: Long); suspend fun delete(id: Long)
    suspend fun detectCurrent(): AppResult<Location>                 // Fused coarse location → reverse через geocoding
}

interface SettingsRepository {   // тонкая обёртка над SettingsDataSource
    val settings: Flow<UserSettings>
    suspend fun setTemperatureUnit(...); suspend fun setWindSpeedUnit(...); suspend fun setTheme(...)
}
```

## Ключевая логика `observeWeather()`

```kotlin
locationDao.observeSelected().flatMapLatest { selected ->
    if (selected == null) flowOf(null)
    else combine(weatherDao.observeCurrent(selected.id),
                 weatherDao.observeHourly(selected.id),
                 weatherDao.observeDaily(selected.id)) { c, h, d -> mapToWeatherData(selected, c, h, d) }
}.flowOn(ioDispatcher)
```

`flatMapLatest` — чтобы смена города автоматически переключала поток погоды. Это самое «архитектурное» место проекта — уметь объяснить.

## `refresh()` — политика

1. Читает selected location и настройки единиц (первые значения Flow)
2. `networkDataSource.getForecast(...)` → при ошибке вернуть `Failure`, кэш НЕ трогать
3. Успех → мапперы DTO→Entity → `weatherDao.replaceForecast(...)` (одна транзакция), `updatedAt = now`
4. Уведомить виджет (см. `23-module-widget.md`) — через интерфейс `WidgetUpdater`, объявленный здесь, реализованный в `:widget` (инверсия зависимости, чтобы data не зависел от widget)

Auto-refresh «если старше 30 минут» — решает вызывающая сторона (ViewModel при старте экрана) по `updatedAt`; сам репозиторий политику не навязывает.

## Мапперы — отдельные файлы-функции, всё покрыть тестами

- `ForecastResponseDto.toEntities(locationId)` — «сшивка» параллельных массивов hourly/daily (главный кандидат на off-by-one баги); часовой срез: от текущего часа, 24 шт.
- `PlaceDto.toLocation()`, `Entity → доменные модели`, `WeatherType.fromWmoCode` применяется здесь

## Геолокация (`detectCurrent()`)

- Только `ACCESS_COARSE_LOCATION`; сам permission запрашивает UI, репозиторий предполагает, что разрешение уже есть (иначе `AppError.Unknown` → UI ведёт в поиск)
- `fusedClient.getCurrentLocation(PRIORITY_BALANCED_POWER_ACCURACY)` (не lastLocation — может быть null/протухшей)
- Координаты → geocoding search → ближайший населённый пункт

## Тесты
Репозитории — с fake `NetworkDataSource` и in-memory Room: refresh-успех обновляет БД; refresh-ошибка НЕ трогает кэш; смена selected переключает observeWeather; все мапперы на реальных JSON-сэмплах.

## Критерии готовности
- [ ] UI не видит ни DTO, ни Entity — только модели из `:core:model`
- [ ] В авиарежиме observeWeather отдаёт кэш, refresh возвращает `AppError.Network`
