# 13 — Модуль `:core:network`

**Роль:** всё общение с интернетом. Наружу отдаёт интерфейс `NetworkDataSource` и DTO; Retrofit/OkHttp — детали реализации, наружу не торчат (`implementation`, не `api`).

**Зависимости:** `:core:common`, `:core:model` (только для координат/параметров; DTO в модели не мапим — это работа `:core:data`). Библиотеки: retrofit, okhttp, kotlinx-serialization + конвертер.

## Содержимое

```
core/network/src/main/kotlin/...
├── retrofit/
│   ├── ForecastApi.kt        // Retrofit-интерфейс api.open-meteo.com
│   └── GeocodingApi.kt       // Retrofit-интерфейс geocoding-api.open-meteo.com  ← ⚠️ два разных baseUrl → два Retrofit-инстанса (Hilt-квалификаторы)
├── dto/
│   ├── ForecastResponseDto.kt   // @Serializable; поля через @SerialName("temperature_2m")
│   └── GeocodingResponseDto.kt  // val results: List<PlaceDto> = emptyList()  ← дефолт обязателен!
├── NetworkDataSource.kt      // interface: suspend fun getForecast(lat, lon, units): AppResult<ForecastResponseDto>
│                             //            suspend fun searchPlaces(query, language): AppResult<List<PlaceDto>>
├── RetrofitNetworkDataSource.kt  // реализация + safeApiCall
└── di/NetworkModule.kt       // OkHttp (таймауты 10с, logging в debug), Json { ignoreUnknownKeys = true }, Retrofit ×2, @Binds DataSource
```

## Ключевые фрагменты

```kotlin
interface ForecastApi {
    @GET("v1/forecast")
    suspend fun getForecast(
        @Query("latitude") lat: Double, @Query("longitude") lon: Double,
        @Query("current") current: String = CURRENT_PARAMS,   // константы со списками полей
        @Query("hourly") hourly: String = HOURLY_PARAMS,
        @Query("daily") daily: String = DAILY_PARAMS,
        @Query("timezone") tz: String = "auto",
        @Query("forecast_days") days: Int = 7,
        @Query("temperature_unit") tempUnit: String,          // из настроек
        @Query("wind_speed_unit") windUnit: String,
    ): ForecastResponseDto
}

suspend fun <T> safeApiCall(block: suspend () -> T): AppResult<T> = try {
    AppResult.Success(block())
} catch (e: IOException) { AppResult.Failure(AppError.Network) }
  catch (e: HttpException) { AppResult.Failure(AppError.Server(e.code())) }
  catch (e: CancellationException) { throw e }   // ⚠️ корутинную отмену НЕ глотать — классическая ошибка
  catch (e: Exception) { AppResult.Failure(AppError.Unknown) }
```

## Решение по единицам измерения

Единицы (°C/°F, м/с) передаём **параметрами запроса** — конвертирует сервер. Trade-off: смена единиц требует нового запроса, зато нет своей математики конверсии. Альтернатива (хранить в СИ, конвертировать в UI) — тоже валидна; выбор зафиксировать в README.

## Тесты (MockWebServer)

- Успешный парсинг реального сэмпла ответа (сохранить JSON в `src/test/resources`)
- `results` отсутствует у геокодинга → пустой список, не крэш
- HTTP 500 → `AppError.Server`, обрыв соединения → `AppError.Network`
- Неизвестные поля в JSON игнорируются (`ignoreUnknownKeys`)

## Критерии готовности
- [ ] Ни один тип Retrofit/OkHttp не виден за пределами модуля
- [ ] Все тесты выше зелёные; логирование тел запросов отключено в release
