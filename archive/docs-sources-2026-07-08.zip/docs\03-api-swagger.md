# 03 — REST API и Swagger/OpenAPI

## Выбор API: Open-Meteo

**Почему Open-Meteo, а не OpenWeatherMap:** бесплатно и **без API-ключа** (нечего прятать в репозитории — для публичного портфолио это большой плюс), честный REST + JSON, есть **официальная OpenAPI-спецификация** (то, что нужно для Swagger-практики), лицензия CC-BY 4.0 (нужна атрибуция в «О приложении»).

Два сервиса, оба без авторизации:

### 1. Прогноз — `GET https://api.open-meteo.com/v1/forecast`

Пример (Сургут):

```
/v1/forecast?latitude=61.25&longitude=73.39
  &current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,surface_pressure,is_day
  &hourly=temperature_2m,weather_code,precipitation_probability
  &daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset
  &timezone=auto&forecast_days=7
  &temperature_unit=celsius&wind_speed_unit=ms        ← единицы прокидываем из настроек
```

Ответ (сокращённо) — обрати внимание: hourly/daily это **параллельные массивы**, а не массив объектов:

```json
{
  "current": { "time": "2026-07-08T14:00", "temperature_2m": 21.4, "weather_code": 3, "wind_speed_10m": 4.2, "is_day": 1 },
  "hourly":  { "time": ["2026-07-08T00:00", ...], "temperature_2m": [17.1, ...], "weather_code": [2, ...] },
  "daily":   { "time": ["2026-07-08", ...], "temperature_2m_max": [22.5, ...], "sunrise": ["2026-07-08T02:57", ...] }
}
```

Маппер в `:core:data` «сшивает» параллельные массивы в список объектов — хорошая задача на unit-тест.

### 2. Геокодинг — `GET https://geocoding-api.open-meteo.com/v1/search`

```
/v1/search?name=Сургут&count=5&language=ru
→ { "results": [ { "id": 1490624, "name": "Сургут", "latitude": 61.25, "longitude": 73.39,
                   "country": "Россия", "admin1": "ХМАО" } ] }
```

⚠️ При пустом результате поле `results` **отсутствует** в JSON — DTO должно иметь `val results: List<...> = emptyList()`.

### Коды погоды (WMO weather_code)

API отдаёт число — маппим в enum `WeatherType` (иконка + строковый ресурс): 0 ясно; 1–3 облачно; 45,48 туман; 51–57 морось; 61–67 дождь; 71–77 снег; 80–82 ливень; 85–86 снегопад; 95–99 гроза. Полная таблица — в доке Open-Meteo. Маппинг — чистая функция, покрыть тестом.

## План работы со Swagger (4 шага, по нарастающей)

1. **Изучение (этап 2):** открыть [editor.swagger.io], вставить официальную спеку Open-Meteo (файл `openapi.yml` в их GitHub-репозитории `open-meteo/open-meteo`), поизучать схемы, погонять запросы через «Try it out».
2. **Своя спека (этап 2):** написать руками урезанную `openapi/weather-api.yaml` **только под используемые поля** (два path, схемы ответов). Это главное учебное упражнение: понять структуру OpenAPI 3 (paths, parameters, components/schemas, $ref). Файл лежит в репозитории — «контракт» проекта.
3. **Кодогенерация (этап 2, ветка-эксперимент):** Gradle-плагин `org.openapi.generator` генерирует DTO из своей спеки:

```kotlin
// build.gradle.kts модуля :core:network
openApiGenerate {
    generatorName.set("kotlin")
    inputSpec.set("$rootDir/openapi/weather-api.yaml")
    outputDir.set(layout.buildDirectory.dir("generated/openapi").get().asPath)
    configOptions.set(mapOf(
        "library" to "jvm-retrofit2",
        "serializationLibrary" to "kotlinx_serialization",
        "useCoroutines" to "true",
    ))
}
// + добавить сгенерированные исходники в sourceSets и повесить задачу перед compile
```

   Сравни сгенерированное с рукописным и **осознанно выбери**: оставить кодоген или руки. Рекомендация: в main оставить рукописные DTO (их мало, полный контроль), спеку хранить как документацию, а опыт кодогена описать в README. Честный trade-off — отличная история для собеседования.
4. **Свой Swagger UI (этап 9, опционально):** мини-бэкенд на **Ktor** — прокси/агрегатор Open-Meteo (`GET /api/v1/weather?lat&lon` — один аккуратный JSON вместо параллельных массивов, кэш на стороне сервера). Документация через OpenAPI-плагин Ktor + Swagger UI на `/swagger`. Деплой не обязателен — достаточно `docker compose up` и скриншота Swagger UI в README.

## Контракт сетевого слоя

- Таймауты OkHttp: connect/read 10 с. Ретраев не делаем (WorkManager и pull-to-refresh покрывают).
- Все вызовы через `safeApiCall { ... }` → `AppResult` (см. `11-module-core-common.md`): IOException → `AppError.Network`, HTTP != 2xx → `AppError.Server(code)`, SerializationException → `AppError.Unknown` (+ лог — значит, контракт разошёлся).
- `HttpLoggingInterceptor` — уровень BODY только в debug-сборке.
