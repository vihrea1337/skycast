# 18 — Модуль `:core:designsystem`

**Роль:** тема Material 3 + переиспользуемые UI-компоненты + иконки. Зависит только от Compose и `:core:model` (для `WeatherType`). Никаких ViewModel, репозиториев, строк бизнес-логики.

## Тема (`theme/`)

- `Theme.kt`: `SkyCastTheme(darkTheme = isSystemInDarkTheme(), dynamicColor = true)` — dynamic color на Android 12+, свои `lightColorScheme`/`darkColorScheme` как fallback (палитру сгенерировать в Material Theme Builder)
- `Type.kt`: типографика (достаточно системного шрифта + выделенный крупный стиль для температуры, например `displayLarge` 64sp)
- Реакция на настройку темы: параметр `themeMode` прокидывается из `:app` (MainActivity собирает `ObserveSettingsUseCase` → `SkyCastTheme`)

## Иконки погоды

`WeatherType` → векторные иконки (`ImageVector` или drawable). Источник: набор [Material Symbols weather] или открытые SVG-паки (лицензию — в NOTICE). Учитывать `isDay` (солнце/луна для CLEAR). Единая точка:

```kotlin
@Composable fun WeatherIcon(type: WeatherType, isDay: Boolean, modifier: Modifier = Modifier)
fun WeatherType.labelRes(): Int   // строковый ресурс описания («Пасмурно») — строки тоже здесь
```

## Компоненты (`component/`)

| Компонент | Использование |
|---|---|
| `LoadingContent` — скелетоны/shimmer | Home при первой загрузке |
| `ErrorContent(error, onRetry)` — полноэкранная ошибка | Home без кэша, Search |
| `MetricChip(icon, label, value)` — «влажность 62%» | Блок метрик Home |
| `SkyCastTopBar` | Все экраны |
| `SectionCard` — карточка секции | Hourly/Daily блоки |

Правило: компонент попадает сюда, только если нужен ≥2 фичам или является частью языка дизайна; одноразовые составные блоки живут в своей фиче.

## Превью — витрина модуля

На каждый компонент — `@Preview` в обоих темах (`@PreviewLightDark`). Это и документация, и материал для скриншотов в README.

## Тонкости

- Все размеры/отступы — через небольшой объект `Dimens` или прямо в компонентах; магические числа по коду не разбрасывать.
- ContentDescription у иконок обязателен (или `null` для декоративных) — базовая доступность, отметить в README.
- Цвета только из `MaterialTheme.colorScheme` — иначе тёмная тема развалится.

## Критерии готовности
- [ ] Каталог превью открывается и не стыден
- [ ] Ни одного `Color(0xFF...)` в feature-модулях
