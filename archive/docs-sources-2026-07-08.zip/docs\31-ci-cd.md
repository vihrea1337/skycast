# 31 — CI/CD и качество кода

## Статический анализ (этап 0)

- **detekt** + плагин `detekt-formatting` (внутри — ktlint): один инструмент, две задачи. Конфиг `config/detekt/detekt.yml` (сгенерировать дефолтный и подкрутить), `./gradlew detekt`.
- Полезные строгие правила: `MagicNumber` (с исключениями для dp/sp в Compose), `ForbiddenImport` на `Dispatchers.IO` вне `:core:common` (защита правила инжекта диспетчеров).
- Android Lint: `./gradlew lint`, в release-конфиге `abortOnError = true`.

## GitHub Actions — `.github/workflows/ci.yml`

```yaml
name: CI
on:
  push: { branches: [main] }
  pull_request:

concurrency:                       # не гонять два CI на одну ветку
  group: ci-${{ github.ref }}
  cancel-in-progress: true

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - uses: gradle/actions/setup-gradle@v4      # кэш Gradle из коробки
      - run: ./gradlew detekt lint testDebugUnitTest assembleDebug --stacktrace
      - uses: actions/upload-artifact@v4
        if: failure()                              # репорты только при падении
        with: { name: reports, path: '**/build/reports/**' }
```

Примечания: точные версии actions проверить на актуальность при настройке; instrumentation-тесты в CI не гоняем (эмулятор в Actions медленный и капризный) — Room-тесты перевести на Robolectric, чтобы шли как unit.

## Release-workflow (этап 8, по тегу)

`on: push: tags: ['v*']` → сборка `assembleRelease` с подписью (keystore в base64 → GitHub Secrets: `KEYSTORE_B64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`) → приложить APK к GitHub Release (`softprops/action-gh-release`). Публикация в Play Store для портфолио не обязательна; если захочется — отдельная история с Play Console ($25) и fastlane.

## Гигиена репозитория

- Бейдж CI в README: `![CI](https://github.com/<user>/<repo>/actions/workflows/ci.yml/badge.svg)`
- Branch protection на `main`: требовать зелёный CI (работает и в личном репо)
- Dependabot/Renovate для версий — приятный бонус, показывает зрелость
- В `.gitignore`: `local.properties`, `keystore.properties`, `*.jks`, `build/`, `.idea/` (кроме пары полезных файлов — codeStyles)

## Критерии готовности
- [ ] PR с падающим тестом невозможно смержить
- [ ] Полный CI-прогон < 10 мин (иначе — смотреть кэш)
