# 23 — Модуль `:widget`

**Роль:** виджет домашнего экрана на Glance. Гвоздь программы для портфолио — виджеты умеют делать немногие джуниоры.

Зависит от `:core:domain` (или `:core:data`), `:core:model`, Glance (`androidx.glance:glance-appwidget`), WorkManager, Hilt.

## Компоненты

```
widget/src/main/kotlin/...
├── WeatherWidget.kt            // GlanceAppWidget: content()
├── WeatherWidgetReceiver.kt    // GlanceAppWidgetReceiver (регистрируется в манифесте ЭТОГО модуля)
├── WeatherWidgetWorker.kt      // @HiltWorker CoroutineWorker: refresh + updateAll
├── AppWidgetUpdater.kt         // реализация интерфейса WidgetUpdater из :core:data (@Binds)
└── ui/                         // WidgetContent: компактный и средний лэйауты
```

## Данные в виджете

Glance-контент — не обычный Compose: он рендерится в RemoteViews, **ViewModel и collectAsState недоступны**. Правильный паттерн:

```kotlin
override suspend fun provideGlance(context: Context, id: GlanceId) {
    // Hilt в GlanceAppWidget не инжектится — берём зависимости через EntryPoint:
    val repo = EntryPointAccessors.fromApplication(context, WidgetEntryPoint::class.java).weatherRepository()
    val weather = repo.observeWeather().first()   // снапшот из Room — сеть здесь НЕ дёргаем
    provideContent { GlanceTheme { WidgetContent(weather) } }
}
```

## Два размера (`SizeMode.Responsive`)

- **Компактный (~2×1):** иконка, температура, город
- **Средний (~4×2):** + описание, min/max, 3–4 ближайших часа

`GlanceModifier` вместо `Modifier`, `GlanceTheme.colors` — поддержка тёмной темы и dynamic color из коробки.

## Обновление — два канала

1. **Периодика:** `PeriodicWorkRequest<WeatherWidgetWorker>(30, MINUTES)` + `enqueueUniquePeriodicWork(KEEP)`, constraint `NetworkType.CONNECTED`. Ставится в `onEnabled` ресивера (появился первый виджет), снимается в `onDisabled`. Worker: `refresh()` → `WeatherWidget().updateAll(context)`; при ошибке сети → `Result.retry()` (backoff по умолчанию)
2. **Мгновенно из приложения:** `WeatherRepository.refresh()` после успеха зовёт `WidgetUpdater.updateAll()` — виджет всегда синхронен приложению

## Поведение

- Клик по виджету — `actionStartActivity<MainActivity>()`
- Нет данных (виджет добавлен до первого запуска приложения) — заглушка «Открой приложение» + тот же клик
- В `xml/weather_widget_info.xml`: `updatePeriodMillis="0"` (обновляет только WorkManager), `previewImage`/`description` — превью в пикере виджетов

## Подводные камни

- `@HiltWorker` требует `HiltWorkerFactory` в Application (`Configuration.Provider`) и **удаления** дефолтного WorkManager-инициализатора из манифеста (`tools:node="remove"` для `androidx.startup` провайдера WorkManager) — забывают все.
- Минимальный интервал PeriodicWork — 15 мин; система может сдвигать (Doze) — «обновлено N мин назад» в среднем лэйауте честно это показывает.
- Тестировать смену темы системы и ресайз виджета — Glance с Responsive перерисовывает сам, но лэйауты должны выдерживать.

## Критерии готовности
- [ ] Виджет живёт сутки на реальном устройстве, данные не старше ~30–40 мин при наличии сети
- [ ] Refresh в приложении мгновенно обновляет виджет
- [ ] После ребута устройства виджет продолжает обновляться (PeriodicWork переживает reboot)
