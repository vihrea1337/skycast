# 20 — Модуль `:feature:home`

**Роль:** главный экран — текущая погода + почасовой и недельный прогноз. Зависит от `:core:domain`, `:core:designsystem`, `:core:model`, `:core:common`.

## Структура

```
feature/home/src/main/kotlin/...
├── HomeViewModel.kt
├── HomeScreen.kt        // HomeRoute (обвязка с VM) + HomeScreen (stateless, принимает state и колбэки)
├── HomeUiState.kt
├── components/          // CurrentWeatherBlock, HourlyRow, DailySection, MetricsRow — приватные для фичи
└── navigation/HomeNavigation.kt   // @Serializable data object HomeRoute + NavGraphBuilder.homeScreen(...)
```

## UiState и ViewModel

```kotlin
sealed interface HomeUiState {
    data object Loading : HomeUiState
    data object NoCity : HomeUiState                       // первый запуск: ведём в поиск/геолокацию
    data class Content(val weather: WeatherData, val settings: UserSettings,
                       val isRefreshing: Boolean, val transientError: AppError?) : HomeUiState
    data class Error(val error: AppError) : HomeUiState    // только когда кэша нет вообще
}
```

- База: `ObserveWeatherUseCase()` + флаги → `stateIn(WhileSubscribed(5_000), Loading)`
- `init`: если `updatedAt` старше 30 мин (или кэша нет) → `refresh()`
- `onRefresh` (pull-to-refresh): `RefreshWeatherUseCase`; ошибка при живом кэше → `transientError` → snackbar (показ через `SnackbarHostState`, сброс события после показа), кэш остаётся на экране
- ⚠️ Не хранить `WeatherData` в двух местах — единственный источник это Flow; флаги (`isRefreshing`) — отдельный `MutableStateFlow`, соединять через `combine`

## Разметка экрана (сверху вниз)

1. TopBar: название города (клик → Search), иконки поиска и настроек
2. Блок текущей погоды: крупная температура, иконка, описание, «ощущается как», «обновлено N мин назад»
3. Метрики: ветер / влажность / давление (`MetricChip` ×3)
4. «Сегодня по часам» — `LazyRow`, 24 карточки (время, иконка, t°, вероятность осадков)
5. «7 дней» — `Column` карточек (день недели, иконка, min/max, для сегодня — восход/закат)
6. Контейнер: `PullToRefreshBox`, контент в `LazyColumn` (секции — item/items)

## Форматирование (utils внутри фичи)

- Температура: округление до целого, знак единицы из настроек (`«21°», «-7°»`)
- Время/даты: `DateTimeFormatter.ofPattern(..., locale)` — «Сейчас», «15:00», «Ср, 9 июл»
- «Обновлено N мин назад»: относительное время; > 24 ч — показать дату и жёлтую пометку устаревания

## Тесты
- ViewModel (Turbine + fake use cases): Loading→Content; ошибка без кэша→Error; ошибка с кэшем→Content+transientError; NoCity когда нет выбранного города
- Compose-тест: Content-state рендерит температуру и 24 часовых элемента

## Критерии готовности
- [ ] Поворот экрана не перезапускает загрузку (WhileSubscribed + stateIn)
- [ ] Первый запуск без города не крэшится — состояние NoCity с кнопками «Найти город» / «Моё местоположение»
