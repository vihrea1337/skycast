# 21 — Модуль `:feature:search`

**Роль:** поиск города + управление сохранёнными городами + кнопка «моё местоположение». Зависит от `:core:domain`, `:core:designsystem`, `:core:model`, `:core:common`.

## Экран

1. Поле поиска (автофокус при открытии)
2. Пока поле пустое — список **сохранённых городов**: текущий отмечен, клик = выбрать и вернуться на Home, свайп/иконка = удалить
3. При вводе — результаты геокодинга: «Сургут, ХМАО, Россия»; клик = сохранить + выбрать + назад
4. Кнопка «Использовать моё местоположение» (с иконкой) — сверху списка сохранённых

## Поиск с debounce — эталонная реализация

```kotlin
private val query = MutableStateFlow("")

val searchResults: StateFlow<SearchResultsState> = query
    .debounce(300)
    .distinctUntilChanged()
    .mapLatest { q ->                       // mapLatest: новый ввод отменяет висящий запрос
        if (q.trim().length < 2) SearchResultsState.Idle
        else when (val r = searchCityUseCase(q)) {
            is AppResult.Success -> if (r.data.isEmpty()) SearchResultsState.Empty
                                    else SearchResultsState.Results(r.data)
            is AppResult.Failure -> SearchResultsState.Error(r.error)
        }
    }
    .stateIn(viewModelScope, WhileSubscribed(5_000), SearchResultsState.Idle)
```

Знать наизусть, почему тут `debounce` + `distinctUntilChanged` + `mapLatest` — топовый вопрос на собеседованиях.

## Разрешение на геолокацию (весь flow — в этой фиче)

- `rememberLauncherForActivityResult(RequestPermission())` c `ACCESS_COARSE_LOCATION`
- Дано → `DetectMyLocationUseCase` (лоадер на кнопке) → успех = назад на Home
- Отказ → snackbar «Можно выбрать город вручную» (не давить)
- «Не спрашивать снова» → snackbar с кнопкой в настройки приложения (`Settings.ACTION_APPLICATION_DETAILS_SETTINGS`)
- ⚠️ В манифесте фичи разрешение не дублировать — оно уже в `:app`

## Состояния списка

`Idle` (сохранённые города) / `Searching` (прогресс) / `Results` / `Empty` («ничего не нашли») / `Error` (сеть — с Retry). Для каждого — свой компонент, всё превьюится.

## Тонкости

- Удаление выбранного города: если города остаются — selected переезжает на первый (логика в `DeleteLocationUseCase`); если это последний — Home возвращается в NoCity. Оба случая проверить руками и тестом.
- Результаты геокодинга не сохраняются в БД, пока пользователь не кликнул.
- `language=ru` в запросе геокодинга — из `Locale.getDefault().language`.

## Тесты
- ViewModel: debounce (advanceTimeBy), отмена предыдущего запроса, min-длина запроса, Empty/Error состояния

## Критерии готовности
- [ ] Быстрый набор «сур→сургут» не порождает очередь запросов (видно в логах OkHttp)
- [ ] Полный цикл: найти → выбрать → Home показывает новый город; удалить → selected корректно переезжает
