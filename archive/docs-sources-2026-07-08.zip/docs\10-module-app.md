# 10 — Модуль `:app`

**Роль:** точка сборки. Единственный модуль с плагином `com.android.application`. Кода минимум — только «клей».

## Зависимости
Все `:feature:*`, `:widget`, `:core:designsystem`, `:core:data` (только чтобы Hilt увидел биндинги data-слоя — сам код `:app` data-классы не трогает).

## Содержимое

```
app/src/main/kotlin/.../ 
├── SkyCastApplication.kt   // @HiltAndroidApp; конфиг WorkManager (HiltWorkerFactory)
├── MainActivity.kt         // @AndroidEntryPoint, single activity, enableEdgeToEdge(), installSplashScreen()
└── navigation/
    └── SkyCastNavHost.kt   // NavHost, связывает маршруты фич
```

## Навигация

Маршруты объявлены type-safe в самих фичах, NavHost собирает их здесь:

```kotlin
NavHost(navController, startDestination = HomeRoute) {
    homeScreen(onSearchClick = { navController.navigate(SearchRoute) },
               onSettingsClick = { navController.navigate(SettingsRoute) })
    searchScreen(onBack = navController::popBackStack)
    settingsScreen(onBack = navController::popBackStack)
}
```

Фичи не знают друг о друге — только колбэки, которые `:app` превращает в navigate. Это и есть ответ на «как фичи общаются при мультимодульности».

## Manifest

- `INTERNET`, `ACCESS_COARSE_LOCATION` (fine не нужен — для погоды хватает города)
- `MainActivity`: `android:exported="true"`, launcher intent, `windowSoftInputMode="adjustResize"`
- Receiver виджета регистрируется в `:widget` (манифесты мёржатся)

## Сборка

- `debug` (суффикс `.debug` — чтобы стояли обе версии) и `release`: `isMinifyEnabled = true`, `isShrinkResources = true`, proguard-правила
- ⚠️ После включения R8 проверить: kotlinx.serialization и Retrofit требуют consumer-правил (обычно едут с библиотеками, но release-сборку прогнать руками — классическая ловушка)
- Подпись release: keystore локально + `keystore.properties` в `.gitignore`

## Критерии готовности
- [ ] Приложение стартует < 2 с, сплэш без «двойной заставки»
- [ ] Навигация back-stack корректна (back из Search возвращает на Home, не выходит из приложения)
- [ ] Release-сборка с R8 работает на устройстве
