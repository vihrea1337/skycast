# 30 — Стратегия тестирования

Цель — не процент покрытия, а **страховка ключевой логики**: мапперы, репозитории, use cases, ViewModel. UI-тесты — минимальный smoke. Это честная стратегия для пет-проекта, её легко защитить на собеседовании.

## Инструменты

| Что | Чем | Где |
|---|---|---|
| Unit-тесты | JUnit4 + kotlin.test assertions | все модули, `src/test` |
| Корутины/время | kotlinx-coroutines-test (`runTest`, `StandardTestDispatcher`) | везде, где suspend/Flow |
| Flow-ассеры | Turbine (`flow.test { awaitItem() }`) | ViewModel, репозитории |
| Моки | MockK | use cases, ViewModel; в data-слое предпочитать **fake** реализации |
| Сеть | MockWebServer (OkHttp) | `:core:network` |
| БД | Room in-memory + Robolectric (или androidTest) | `:core:database`, `:core:data` |
| Compose UI | createAndroidComposeRule, semantics | smoke в `:feature:home` |

## Что тестируем по модулям (сводка — детали в доках модулей)

- `:core:model` — `WeatherType.fromWmoCode`: все группы WMO-кодов
- `:core:network` — парсинг реальных JSON-сэмплов (в `src/test/resources`), отсутствующее поле `results`, HTTP 500 → `AppError.Server`, обрыв → `AppError.Network`
- `:core:database` — replaceForecast атомарность, эксклюзивность isSelected, CASCADE
- `:core:data` — мапперы (сшивка параллельных массивов! краевые случаи: пустые массивы, разная длина), refresh-ошибка не портит кэш, flatMapLatest при смене города
- `:core:domain` — композитные сценарии: порядок вызовов, падение на середине
- `:feature:*` — ViewModel через Turbine: переходы состояний, debounce поиска (`advanceTimeBy`), transientError

## Паттерны и правила

```kotlin
// Правило Given-When-Then + говорящие имена через backticks:
@Test fun `refresh failure keeps cached weather and exposes transient error`() = runTest { ... }
```

- **MainDispatcherRule** (JUnit-правило, подменяющее `Dispatchers.Main` на тестовый) — общий код положить в `:core:testing` (test-fixtures модуль) вместе с fake-репозиториями и сэмплами моделей.
- Fake > Mock для репозиториев: `FakeWeatherRepository` с `MutableStateFlow` внутри читается лучше и не ломается при рефакторинге сигнатур.
- Один тест — одна причина упасть. Не ассертить полдюжины полей из разных сценариев.
- Тест, который ловил реальный баг, — оставить и подписать комментом. Такие тесты — лучшие.

## Smoke UI-тест (один, но показательный)

`HomeScreen` c fake-данными: отображается температура, город, 24 элемента в hourly, pull-to-refresh дёргает колбэк. Через semantics/testTag, без Espresso-легаси.

## Критерии готовности (этап 7)
- [ ] `./gradlew test` зелёный локально и в CI, длится < 2 мин
- [ ] Поломка любого маппера или контракта DTO валит минимум один тест
